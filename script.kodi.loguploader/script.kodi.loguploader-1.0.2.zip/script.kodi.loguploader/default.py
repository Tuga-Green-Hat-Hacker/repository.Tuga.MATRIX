from lib import loguploader


if (__name__ == '__main__'):
    loguploader.Main()
