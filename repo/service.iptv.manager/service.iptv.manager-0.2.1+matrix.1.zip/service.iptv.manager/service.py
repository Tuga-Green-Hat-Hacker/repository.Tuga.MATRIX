# -*- coding: utf-8 -*-
"""Service entry point"""

from __future__ import absolute_import, division, unicode_literals

from resources.lib import service

service.run()
