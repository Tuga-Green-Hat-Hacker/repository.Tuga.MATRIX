class ApiCollection:
    items = []
    limit = 10
    offset = 0
    next_href = None
