# -*- coding: utf-8 -*-
"""
    Copyright (C) 2021 Stefano Gottardo (script.appcast)
    Default module - Kodi script

    SPDX-License-Identifier: MIT
    See LICENSES/MIT.md for more information.
"""
import sys

from resources.lib.run_script import run

run(sys.argv)
